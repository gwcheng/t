function ethylene_confirm(){
		confirm("計算能源消耗前須先完成乙烯產量計算");
}
function delete_confirm(){
		confirm("歷史紀錄刪除後將無法復原，是否確認刪除?");
}
function delete_accnt_confirm(){
		confirm("帳號刪除後將無法復原，是否確認刪除?");
}
function reCalc(){
		confirm("尚未儲存計算結果，是否確定再次計算?");
}
function replaceParameter_confirm(){
		confirm("參數紀錄將會被覆蓋，是否確定重新匯入參數?");
}

function excedRange(){
	confirm("參數超過範圍，請確認是否執行？");
}
function import_parameter_alert(){
	alert("參數檔案錯誤、無法匯入參數");
}
function chkbox_checked(){
	alert("請至少勾選一個參數以進行參數建議");
}
function userIptAlert(){
	alert("帳號格式有誤，請重新輸入");
}
function forgetPwd(){
	prompt("輸入電子信箱");
}
function PwdCheck(){
	alert("帳號或密碼錯誤，請重新輸入");
}


